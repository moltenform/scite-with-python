SsipScite
2011, Ben Fisher, GPLv3
Refer to http://halfhourhacks.blogspot.com/2012/02/ssipscite.html

SsipScite is a fork of the SciTE code editor with added support for Python extensions and source indexing.
If one is working in a C or C++ codebase (even a large one with many thousands of files),
one can click on a function or method and press F12 to go to its definition,
Shift- F12 to go to the definition of a function/method/class,
or Ctrl-F12 to list references to a function/method/class.

Example:
Let's say I'm working on the 7z project.
Create a text file ssipscite/plugins/searchsip_userprefs/7z_example.cfg
with the contents

[main]
srcdir1=C:\delldev\dev_here\ssipscite\example

This tells SsipScite that it can create an index of all source code in this directory. (I happened to put this in
C:\delldev\dev_here\ssipscite\example, you'll have to change the path to where you put it).

Then, I can start ssipscite\SciTE.exe, and open 7zIn.c.


What does CSzCoderInfo refer to? I can press F12 and go to the definition:


What other files refer to this struct? I can press Ctrl-F12 and list references:


After the index is created, these searches are noticeably faster than full-text search, and they intelligently point
you to just the information you needed. Pretty useful, huh?

For more information about Ssip (the source indexing backend), 
see 
http://halfhourhacks.blogspot.com/2012/01/ssip.html
SsipScite works great for large codebases that cause Visual Studio to feel slow; it indexes literally hundreds of files a second
and subsequent updates are fast and incremental.

