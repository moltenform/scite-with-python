
import re
import searchutil
from searchutil import assertEqual, assertContains, assertNotEqual, SipException


def isHeader(path):
	return path.endswith('.h') or path.endswith('.H')

# filter the matches based on mode, i.e. if mode is IndexedDefn try to look for a definition
def filter(sMode, sQuery, sRawresults):
	checkStringOk(sQuery)
	filter = CFilterResults()
	filter.sIn = sQuery
	
	# tag each hit as a type
	arResults = []
	txt = sRawresults.replace('\r\n','\n')
	for line in txt.split('\n'):
		if line.count('\\')==0:
			print 'Info: ',line
		else:
			path, num, context = pullapartline(line)
			context = searchutil.killcomments(context)
			rettype = filter.lookAtLine(context, path)
			if rettype!='NO_MATCH':
				arResults.append((rettype, line, path))
	
	# eliminate results that do not match the condition -- unless no results match the condition
	def filterButNotAll(ar, fn):
		arTmp = [item for item in ar if fn(item)]
		if len(arTmp)==0 and len(ar)>0: print 'Only results:'
		else: ar = arTmp
		return ar
	
	# further filtering based on mode
	if sMode=='IndexedAll':
		pass
	elif sMode=='IndexedOther':
		# (i.e. 'see usage not definition')
		arResults = filterButNotAll(arResults, lambda item: item[0]=='OTHER_MATCH')
	elif sMode=='IndexedDefn' or sMode=='IndexedImpl':
		arResults = filterButNotAll(arResults, lambda item: item[0]!='OTHER_MATCH')
		if sMode=='IndexedDefn':
			preferSrcOverHeader = -1
			# kill constructor impl
			arResults = filterButNotAll(arResults, lambda item: item[0]!='CONSTR_IMPL')
			# defns shouldn't be in src files.
			arResults = filterButNotAll(arResults, lambda item: item[0]!='METHOD_EITHER' or isHeader(item[2]))
			
		elif sMode=='IndexedImpl':
			preferSrcOverHeader = 1
			# kill methods that end with ');'
			arResults = filterButNotAll(arResults, lambda item: 
				item[0]!='METHOD_EITHER' or not (item[1].rstrip().endswith(';')))
			
			# kill 'class foo' and 'struct foo'
			arResults = filterButNotAll(arResults, lambda item: not (item[0]=='CLASS_DEFN' or item[0]=='STRUCT_DEFN' or item[0]=='IFACE_DEFN'))
		
		# sort by headers first if that, else other. should be a stable sort.
		arResults.sort(key=lambda item: preferSrcOverHeader if isHeader(item[2]) else 0)
		
		# other ideas:
		# if looking for an implementation and there's one without an extern, show that one?
		# ideally, if there's a paired method+impl, only show the appropriate one.
	
	else:
		raise SipException("unknown mode")
	
	if not len(arResults):
		print 'No results found.'
	else:
		for res in arResults:
			print res[1]
	
	return arResults
	
def pullapartline(line):
	line=line.strip()
	if ':' not in line: return
	first, rest = line[0:2], line[2:]
	path, num, context = rest.split(':',2)
	path = first+path
	return path, int(num), context
	

class CFilterResults():
	sIn=None # user input.
	def lookAtLine(self, sLineOrig, path):
		# do -not- need to parse the code. common cases only! do not make matching too strict and accidentally filter out good results.
		# supports: enum, typedef, macro, class, struct, interface, method, inline method, global function, inline fn, global variable, member vars
		# not supported yet: enumconstant, fn ptrs, destructors
		
		# sIn is the user-provided query. s is the purported match.
		s = sLineOrig.strip()
		if not s:
			return 'NO_MATCH' # could happen if the line was all comment
		
		# for convenience, replace all tab/space whitespace with one space character
		s = s.replace('\t', ' ')
		sIn = self.sIn
		bWasIndented = s[0]==' '
		if sIn not in s:
			return 'NO_MATCH'
		s = s.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
		if '  ' in s:
			raise SipException("That's a lot of spaces in this line")
		
		def starts(sinput): return s.startswith(sinput)
		def ends(sinput): return s.endswith(sinput)
		def contains(sinput): return sinput in s
		
		# detect class. (exclude forward declarations)
		sspace = s+' '
		if sspace.startswith('class '+sIn+' ') and not contains(';'):
			return 'CLASS_DEFN'
		if sspace.startswith('struct '+sIn+' ') and not contains(';'):
			return 'STRUCT_DEFN'
		if sspace.startswith('interface '+sIn+' ') and not contains(';'):
			return 'IFACE_DEFN'
		if starts('DECLARE_INTERFACE('+sIn+' ') or starts('DECLARE_INTERFACE( '+sIn+' ') or \
			starts('DECLARE_INTERFACE('+sIn+',') or starts('DECLARE_INTERFACE( '+sIn+','):
			return 'IFACE_DEFN'
		
		# detect enum. (exclude forward declarations)
		if sspace.startswith('enum '+sIn+' ') or sspace.startswith('typedef enum '+sIn+' '):
			if not contains(';') or (contains('{') and contains('}')):
				return 'ENUM_DEFN'
		
		# c-style definitions
		if starts('} ') and ends(';') and not (contains('=') or contains('(') 
			or contains(')') or contains('.') or contains('>')):
			return 'CSTYLE_DEFN'
		
		# typedef
		if starts('typedef ') and (ends(' '+sIn+';') or ends(' '+sIn+' ;') or ends('*'+sIn+';') or ends('*'+sIn+' ;')):
			return 'TYPEDEF_DEFN'
		
		# macro
		if sspace.startswith('#define '+sIn+' ') or starts('#define '+sIn+'('):
			return 'MACRO_DEFN'
		
		
		if starts(sIn+'::'+sIn+'(') or starts(sIn+'::'+sIn+' '):
			# namespace? would anyone ever write Ns::CFoo::CFoo() ?
			return 'CONSTR_IMPL'
		if starts('void '+sIn+'::Init(') or starts('void '+sIn+'::Init '):
			return 'CONSTR_IMPL'
		if starts('bool '+sIn+'::FInit(') or starts('bool '+sIn+'::FInit '):
			return 'CONSTR_IMPL'
		
		# how to identify a method:
		# contains sIn( and after stripping parens and templates, it basically looks like
		# worda sIn p1 p2
		# and nothing else.
		# (this might not match old-style C fns).
		
		if sIn+' (' in s: s=s.replace(sIn+' (', sIn+'(')
		if sIn+'(' in s and not starts(sIn+'('):
			stmp = s
			if re.match(r'.*?\) *= *0 *; *$', stmp): # pure virtual
				stmp = stmp.rsplit('=', 1)[0]
				
			stmp = searchutil.killparens(stmp)
			stmp = searchutil.killtemplates(stmp)
			stmp = searchutil.killbraces(stmp) #kill an inline implementation
			stmp = stmp.strip()
			
			stmp = stmp.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
			if '  ' in stmp:
				raise SipException("That's a lot of spaces in this line")
			
			if '=' not in stmp and ' new ' not in (' '+stmp) and ' return ' not in (' '+stmp):
				#sregexp = r'([a-zA-Z0-9_*~&:]+ +)+[^a-zA-Z0-9_]*'+sIn
				#instead, blacklist
				#remember to write \- inside a char class
				#match() must match start of string. $ ties to end of string
				sregexp = r"([^./+\-!#%={}|',?]+ +)+[^a-zA-Z0-9_]*([a-zA-Z0-9_:]*::)?"+sIn+' *;?$'
				if re.match(sregexp, stmp):
					return 'METHOD_EITHER'
		
		#global var: indent is 0.
		if not bWasIndented and ends(';'):
			stmp = s.split('=')[0]
			spacestmp = ' '+stmp
			if not (' class ' in spacestmp) and not (' struct '  in spacestmp) and not \
			(' interface ' in spacestmp) and not (' enum ' in spacestmp) and not (' new ' in spacestmp) and not \
			(' typedef ' in spacestmp) and not (' friend ' in spacestmp) and not (' return ' in spacestmp) :
				
				stmp = searchutil.killparens(stmp)
				stmp = searchutil.killbrackets(stmp)
				
				sregexp=r"([^./+\-!#%={}|',?]+ +)+[^a-zA-Z0-9_]*"+sIn+' *;?$'
				if re.match(sregexp, stmp):
					return 'VAR_EITHER'
		
		return 'OTHER_MATCH'


def checkStringOk(s):
	if len(s)==1:
		raise SipException("No results! We don't index single characters.")
	if not s or not re.match(r'[a-zA-Z0-9_]+$', s):
		raise SipException("No results! Input can't contain punctuation or spaces.")
